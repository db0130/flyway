package cn.dreampie;

public class FlywayException extends RuntimeException {
  /**
	 * 
	 */
	private static final long serialVersionUID = 2221078534887941910L;

public FlywayException(String message) {
    super(message);
  }

  public FlywayException(String message, Throwable cause) {
    super(message, cause);
  }
}
